The user manual is available in http://www.ncbi.nlm.nih.gov/books/NBK1762
Release notes are available in http://www.ncbi.nlm.nih.gov/books/NBK131777
